/* ============================================================
   🎯 GOUTTEST - MASTER STYLESHEET (NEW)
   ============================================================ */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Plus Jakarta Sans', 'Inter', sans-serif;
    background: #f0f4f9;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 16px;
    transition: background 0.4s ease;
}

body.dark-mode {
    background: #0a0f1a;
}

/* ============================================================
   📦 MAIN WRAPPER
   ============================================================ */
.main-wrapper {
    width: 100%;
    max-width: 420px;
    margin: 0 auto;
}

/* ============================================================
   🃏 CARD - มี overflow: hidden เพื่อให้แถบสีโค้งตาม
   ============================================================ */
.assessment-card {
    position: relative;
    background: rgba(255, 255, 255, 0.88);
    backdrop-filter: blur(24px);
    -webkit-backdrop-filter: blur(24px);
    border-radius: 28px;
    padding: 28px 22px 20px;
    width: 100%;
    box-shadow: 0 16px 48px rgba(10, 36, 99, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.4);
    transition: all 0.4s ease;
    overflow: hidden; /* ✅ สำคัญ! ให้แถบสีถูกตัดตามขอบ */
}

body.dark-mode .assessment-card {
    background: rgba(20, 27, 43, 0.88);
    border-color: rgba(255, 255, 255, 0.04);
    box-shadow: 0 16px 48px rgba(0, 0, 0, 0.3);
}

/* ============================================================
   🎨 ACCENT BAR - โค้งตามขอบการ์ดเป๊ะๆ
   ============================================================ */
.accent-bar {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 5px;
    background: linear-gradient(90deg, #1a3a8a, #2b5b9a, #4a8af4);
    border-radius: 28px 28px 0 0;
    z-index: 1;
    box-shadow: 0 2px 16px rgba(26, 58, 138, 0.12);
}

/* ============================================================
   🔝 TOP BAR (Theme + Language) - ขวาบนทุกหน้า
   ============================================================ */
.top-bar {
    position: fixed;
    top: 14px;
    right: 14px;
    display: flex;
    align-items: center;
    gap: 8px;
    z-index: 999;
}

.top-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: none;
    background: rgba(255, 255, 255, 0.6);
    backdrop-filter: blur(10px);
    color: #1a3a8a;
    font-size: 17px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 2px 16px rgba(0, 0, 0, 0.06);
}

body.dark-mode .top-btn {
    background: rgba(255, 255, 255, 0.08);
    color: #e2e8f0;
}

.top-btn:hover {
    transform: scale(1.08);
    background: rgba(255, 255, 255, 0.85);
    box-shadow: 0 4px 24px rgba(0, 0, 0, 0.1);
}

body.dark-mode .top-btn:hover {
    background: rgba(255, 255, 255, 0.15);
}

.lang-btn {
    width: auto;
    padding: 0 16px;
    border-radius: 24px;
    gap: 6px;
    font-size: 13px;
    font-weight: 600;
    font-family: inherit;
}

.lang-btn i {
    font-size: 15px;
}

/* ============================================================
   🏷️ HEADER
   ============================================================ */
.card-header {
    text-align: center;
    margin-bottom: 16px;
    padding-top: 4px;
}

.brand-icon {
    display: inline-block;
    margin-bottom: 6px;
}

.brand-icon svg {
    width: 48px;
    height: 48px;
}

.card-header h1 {
    font-size: 24px;
    font-weight: 800;
    color: #0a1628;
    margin: 0;
    letter-spacing: -0.3px;
}

.card-header h1 span {
    background: linear-gradient(135deg, #1a3a8a, #4a8af4);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.card-header p {
    font-size: 13px;
    color: #64748b;
    margin: 2px 0 0;
    font-weight: 500;
    line-height: 1.5;
    word-break: break-word;
}

body.dark-mode .card-header h1 {
    color: #fff;
}
body.dark-mode .card-header p {
    color: #94a3b8;
}

/* ============================================================
   📊 STEP INDICATOR
   ============================================================ */
.step-indicator {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    margin-bottom: 20px;
    padding: 0 6px;
}

.step-wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 3px;
}

.step {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: #e2e8f0;
    color: #94a3b8;
    font-weight: 700;
    font-size: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.4s ease;
}

.step.active {
    background: linear-gradient(135deg, #1a3a8a, #2b5b9a);
    color: #fff;
    box-shadow: 0 4px 16px rgba(26, 58, 138, 0.25);
}

.step-label {
    font-size: 9px;
    font-weight: 600;
    color: #94a3b8;
    letter-spacing: 0.3px;
}

.step.active + .step-label {
    color: #1a3a8a;
}

.step-line {
    width: 22px;
    height: 2px;
    background: #e2e8f0;
    border-radius: 2px;
}

body.dark-mode .step {
    background: #1e273a;
    color: #6a8aaa;
}
body.dark-mode .step-line {
    background: #1e273a;
}
body.dark-mode .step-label {
    color: #6a8aaa;
}
body.dark-mode .step.active + .step-label {
    color: #4a8af4;
}

/* ============================================================
   📝 FORM
   ============================================================ */
.form-header {
    margin-bottom: 14px;
}

.form-title {
    font-size: 17px;
    font-weight: 700;
    color: #0a1628;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.form-title i {
    color: #1a3a8a;
    font-size: 17px;
}

.form-subtitle {
    font-size: 13px;
    color: #94a3b8;
    margin: 2px 0 16px;
    font-weight: 500;
    line-height: 1.6;
    word-break: break-word;
    max-width: 100%;
}

body.dark-mode .form-title {
    color: #fff;
}
body.dark-mode .form-title i {
    color: #4a8af4;
}
body.dark-mode .form-subtitle {
    color: #6a8aaa;
}

/* ============================================================
   📋 FORM GRID
   ============================================================ */
.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
}

.input-container {
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.input-container.full-width {
    grid-column: 1 / -1;
}

.input-container label {
    font-size: 11px;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 5px;
}

.input-container label i {
    color: #1a3a8a;
    font-size: 12px;
    width: 14px;
}

.input-container input,
.input-container select {
    padding: 9px 11px;
    border: 2px solid #e2e8f0;
    border-radius: 10px;
    font-size: 13px;
    font-family: inherit;
    transition: all 0.3s ease;
    background: #fafbfc;
    color: #0a1628;
    width: 100%;
    -webkit-appearance: none;
    appearance: none;
}

.input-container input:focus,
.input-container select:focus {
    outline: none;
    border-color: #1a3a8a;
    box-shadow: 0 0 0 3px rgba(26, 58, 138, 0.06);
    background: #fff;
}

.input-container input.error {
    border-color: #ef4444;
    background: #fef2f2;
}

.error-message {
    font-size: 10px;
    color: #ef4444;
    min-height: 14px;
    display: block;
}

.input-container select[multiple] {
    min-height: 60px;
    padding: 6px;
}

.input-container select[multiple] option {
    padding: 4px 8px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
}

.input-container select[multiple] option:checked {
    background: #1a3a8a;
    color: #fff;
}

.input-container small {
    font-size: 9px;
    color: #94a3b8;
    line-height: 1.4;
}

body.dark-mode .input-container label {
    color: #b0c8e8;
}
body.dark-mode .input-container label i {
    color: #4a8af4;
}
body.dark-mode .input-container input,
body.dark-mode .input-container select {
    background: #1e273a;
    color: #e8f0f8;
    border-color: #2a3450;
}
body.dark-mode .input-container input:focus,
body.dark-mode .input-container select:focus {
    border-color: #4a8af4;
    box-shadow: 0 0 0 3px rgba(74, 138, 244, 0.08);
    background: #252f45;
}
body.dark-mode .input-container small {
    color: #5a7a9a;
}

/* ============================================================
   🚀 CTA BUTTON
   ============================================================ */
.cta-button {
    width: 100%;
    padding: 13px;
    margin-top: 16px;
    background: linear-gradient(135deg, #1a3a8a, #2b5b9a);
    color: #fff;
    border: none;
    border-radius: 12px;
    font-size: 15px;
    font-weight: 700;
    font-family: inherit;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    box-shadow: 0 4px 20px rgba(26, 58, 138, 0.2);
}

.cta-button:hover {
    transform: translateY(-2px);
    background: linear-gradient(135deg, #2b5b9a, #3b6aba);
    box-shadow: 0 6px 28px rgba(26, 58, 138, 0.3);
}

.cta-button:active {
    transform: scale(0.97);
}

body.dark-mode .cta-button {
    background: linear-gradient(135deg, #1a3a7a, #2a5a9a);
}

/* ============================================================
   🔙 BACK BUTTON (scan / analysis)
   ============================================================ */
.back-btn {
    position: absolute;
    top: 16px;
    left: 16px;
    z-index: 20;
    width: 36px;
    height: 36px;
    border: none;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.5);
    backdrop-filter: blur(8px);
    color: #1e293b;
    font-size: 15px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}

body.dark-mode .back-btn {
    background: rgba(255, 255, 255, 0.06);
    color: #e2e8f0;
}

.back-btn:hover {
    background: rgba(255, 255, 255, 0.8);
    transform: translateX(-2px);
}

body.dark-mode .back-btn:hover {
    background: rgba(255, 255, 255, 0.12);
}

.back-btn:active {
    transform: scale(0.90);
}

/* ============================================================
   📸 SCAN FRAME (scan.html)
   ============================================================ */
.scanner-wrapper {
    margin-bottom: 16px;
}

.scan-frame {
    position: relative;
    width: 100%;
    aspect-ratio: 4/3;
    border-radius: 20px;
    overflow: hidden;
    background: #0a0f1a;
    border: 2px solid rgba(255, 255, 255, 0.04);
    transition: all 0.4s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.scan-frame.has-image {
    border-color: #22c55e;
}

.scan-frame video {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}

.scan-frame.has-image video {
    opacity: 0.2;
}

.preview-img {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    z-index: 2;
    display: none;
}

.scan-frame.has-image .preview-img {
    display: block;
}

/* ============================================================
   📦 SCAN BOX (กรอบเส้นประตรงกลาง)
   ============================================================ */
.scan-box {
    position: relative;
    width: 38%;
    height: 38%;
    z-index: 2;
    pointer-events: none;
}

.box-border {
    position: absolute;
    inset: 0;
    border: 1.5px dashed rgba(74, 138, 244, 0.35);
    border-radius: 14px;
}

.box-corner {
    position: absolute;
    width: 14px;
    height: 14px;
    z-index: 3;
}

.box-corner::before,
.box-corner::after {
    content: '';
    position: absolute;
    background: rgba(74, 138, 244, 0.6);
    border-radius: 2px;
}

.box-corner.tl {
    top: -2px;
    left: -2px;
}
.box-corner.tl::before {
    top: 0;
    left: 0;
    width: 10px;
    height: 2px;
}
.box-corner.tl::after {
    top: 0;
    left: 0;
    width: 2px;
    height: 10px;
}

.box-corner.tr {
    top: -2px;
    right: -2px;
}
.box-corner.tr::before {
    top: 0;
    right: 0;
    width: 10px;
    height: 2px;
}
.box-corner.tr::after {
    top: 0;
    right: 0;
    width: 2px;
    height: 10px;
}

.box-corner.bl {
    bottom: -2px;
    left: -2px;
}
.box-corner.bl::before {
    bottom: 0;
    left: 0;
    width: 10px;
    height: 2px;
}
.box-corner.bl::after {
    bottom: 0;
    left: 0;
    width: 2px;
    height: 10px;
}

.box-corner.br {
    bottom: -2px;
    right: -2px;
}
.box-corner.br::before {
    bottom: 0;
    right: 0;
    width: 10px;
    height: 2px;
}
.box-corner.br::after {
    bottom: 0;
    right: 0;
    width: 2px;
    height: 10px;
}

.center-dot {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: rgba(74, 138, 244, 0.25);
}

.scan-frame.has-image .scan-box {
    display: none;
}

/* ============================================================
   🎨 COLOR DETECTION BOX (scan.html)
   ============================================================ */
.color-detection-box {
    position: absolute;
    bottom: 16px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 5;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(16px);
    padding: 6px 14px 6px 8px;
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.04);
    opacity: 0;
    transition: opacity 0.5s ease;
    width: auto;
    max-width: 90%;
    white-space: nowrap;
    box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3);
}

.scan-frame.has-image .color-detection-box {
    opacity: 1;
}

.color-preview {
    width: 30px;
    height: 30px;
    border-radius: 8px;
    border: 2px solid rgba(255, 255, 255, 0.1);
    flex-shrink: 0;
    background: #555;
}

.color-info {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
}

.color-label {
    font-size: 8px;
    font-weight: 600;
    color: rgba(255, 255, 255, 0.4);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.color-value {
    font-size: 13px;
    font-weight: 700;
    color: #fff;
    font-family: 'Inter', monospace;
    line-height: 1.2;
}

/* ============================================================
   📸 CAPTURE BUTTON (scan.html)
   ============================================================ */
.capture-wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    margin-top: 6px;
}

.capture-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
    transition: all 0.3s ease;
}

.btn-ring {
    width: 68px;
    height: 68px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.04);
    backdrop-filter: blur(8px);
    border: 2px solid rgba(255, 255, 255, 0.08);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    box-shadow: 0 2px 16px rgba(0, 0, 0, 0.06);
}

.btn-inner {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: linear-gradient(135deg, #1a3a8a, #2b5b9a);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 22px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 16px rgba(26, 58, 138, 0.3);
}

.capture-btn:hover .btn-ring {
    border-color: rgba(255, 255, 255, 0.15);
    transform: scale(1.03);
}

.capture-btn:hover .btn-inner {
    background: linear-gradient(135deg, #2b5b9a, #3b6aba);
    transform: scale(1.02);
}

.capture-btn:active .btn-ring {
    transform: scale(0.94);
}
.capture-btn:active .btn-inner {
    transform: scale(0.92);
}

.capture-btn:disabled {
    pointer-events: none;
}

.scan-frame.has-image ~ .capture-wrapper .btn-ring {
    border-color: rgba(34, 197, 94, 0.2);
}

.scan-frame.has-image ~ .capture-wrapper .btn-inner {
    background: linear-gradient(135deg, #16a34a, #22c55e);
    box-shadow: 0 4px 16px rgba(34, 197, 94, 0.25);
}

.capture-label {
    font-size: 12px;
    color: #94a3b8;
    font-weight: 500;
}

body.dark-mode .capture-label {
    color: #6a8aaa;
}

/* ============================================================
   📊 ANALYSIS PAGE
   ============================================================ */
.result-hero {
    text-align: center;
    padding: 16px 0 8px;
}

.result-circle {
    width: 140px;
    height: 140px;
    border-radius: 50%;
    margin: 0 auto 16px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #1a3a8a, #2b5b9a);
    box-shadow: 0 8px 48px rgba(26, 58, 138, 0.25);
    position: relative;
    transition: all 0.6s ease;
    animation: pulseCircle 2.5s ease-in-out infinite;
}

@keyframes pulseCircle {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.02); }
}

.result-circle .value {
    font-size: 40px;
    font-weight: 800;
    color: #fff;
    line-height: 1;
}

.result-circle .unit {
    font-size: 14px;
    font-weight: 600;
    color: rgba(255, 255, 255, 0.7);
    margin-top: 2px;
}

.result-circle .status-badge {
    position: absolute;
    bottom: -14px;
    padding: 5px 22px;
    border-radius: 24px;
    font-size: 13px;
    font-weight: 700;
    background: #fff;
    color: #1a3a8a;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    white-space: nowrap;
    letter-spacing: 0.3px;
}

.result-circle .status-badge.very-low { color: #22c55e; background: #f0fdf4; }
.result-circle .status-badge.low { color: #3b82f6; background: #eff6ff; }
.result-circle .status-badge.moderate { color: #eab308; background: #fefce8; }
.result-circle .status-badge.high { color: #f97316; background: #fff7ed; }
.result-circle .status-badge.very-high { color: #ef4444; background: #fef2f2; }

body.dark-mode .result-circle .status-badge.very-low { background: #052e16; }
body.dark-mode .result-circle .status-badge.low { background: #172554; }
body.dark-mode .result-circle .status-badge.moderate { background: #422006; }
body.dark-mode .result-circle .status-badge.high { background: #431407; }
body.dark-mode .result-circle .status-badge.very-high { background: #450a0a; }

/* ---- Range Bar ---- */
.range-bar {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    margin: 6px 0 14px;
    font-size: 13px;
    color: #64748b;
}

body.dark-mode .range-bar {
    color: #94a3b8;
}

.range-bar .range-line {
    flex: 1;
    max-width: 160px;
    height: 6px;
    border-radius: 4px;
    background: linear-gradient(90deg, #22c55e, #eab308, #ef4444);
    position: relative;
}

.range-bar .range-line .marker {
    position: absolute;
    top: -6px;
    width: 18px;
    height: 18px;
    border-radius: 50%;
    background: #1a3a8a;
    border: 3px solid #fff;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    transition: left 0.8s ease;
}

body.dark-mode .range-bar .range-line .marker {
    border-color: #1a1f2e;
}

.range-bar .range-label {
    font-weight: 600;
    font-size: 12px;
    min-width: 36px;
    text-align: center;
}

.range-bar .range-label.low { color: #22c55e; }
.range-bar .range-label.normal { color: #3b82f6; }
.range-bar .range-label.high { color: #ef4444; }

/* ---- Stats Grid ---- */
.result-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
    margin: 14px 0;
}

.stat-card {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 14px;
    padding: 14px 10px;
    text-align: center;
    border: 1px solid rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(8px);
    transition: all 0.3s ease;
}

.stat-card:hover {
    background: rgba(255, 255, 255, 0.08);
    transform: translateY(-2px);
}

.stat-card .icon {
    font-size: 18px;
    color: #1a3a8a;
    margin-bottom: 4px;
}

body.dark-mode .stat-card .icon {
    color: #4a8af4;
}

.stat-card .label {
    font-size: 10px;
    font-weight: 600;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.stat-card .value {
    font-size: 18px;
    font-weight: 700;
    color: #0a1628;
    margin-top: 2px;
}

body.dark-mode .stat-card .value {
    color: #e8f0f8;
}

/* ---- Explanation Cards ---- */
.explanation {
    margin: 14px 0;
}

.explanation .section-title {
    font-size: 14px;
    font-weight: 700;
    color: #0a1628;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
}

body.dark-mode .explanation .section-title {
    color: #e8f0f8;
}

.explanation .section-title i {
    color: #1a3a8a;
}

body.dark-mode .explanation .section-title i {
    color: #4a8af4;
}

.exp-card {
    background: rgba(255, 255, 255, 0.04);
    border-radius: 14px;
    padding: 16px 18px;
    margin-bottom: 10px;
    border: 1px solid rgba(255, 255, 255, 0.04);
    border-left: 4px solid #1a3a8a;
    transition: all 0.3s ease;
}

.exp-card:hover {
    background: rgba(255, 255, 255, 0.06);
}

body.dark-mode .exp-card {
    border-left-color: #4a8af4;
}

.exp-card .title {
    font-size: 14px;
    font-weight: 700;
    color: #0a1628;
    margin-bottom: 4px;
    display: flex;
    align-items: center;
    gap: 8px;
}

body.dark-mode .exp-card .title {
    color: #e8f0f8;
}

.exp-card .title .emoji {
    font-size: 18px;
}

.exp-card .desc {
    font-size: 13px;
    color: #475569;
    line-height: 1.7;
}

body.dark-mode .exp-card .desc {
    color: #94a3b8;
}

.exp-card .desc strong {
    color: #0a1628;
}

body.dark-mode .exp-card .desc strong {
    color: #e8f0f8;
}

.exp-card ul {
    margin: 6px 0 0 18px;
    padding: 0;
    list-style: none;
}

.exp-card ul li {
    font-size: 13px;
    color: #475569;
    line-height: 1.8;
    position: relative;
    padding-left: 18px;
}

body.dark-mode .exp-card ul li {
    color: #94a3b8;
}

.exp-card ul li::before {
    content: '•';
    position: absolute;
    left: 0;
    color: #1a3a8a;
    font-weight: 700;
}

body.dark-mode .exp-card ul li::before {
    color: #4a8af4;
}

.exp-card .tag {
    display: inline-block;
    padding: 2px 12px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    margin-top: 6px;
}

.tag.green { background: #dcfce7; color: #16a34a; }
.tag.blue { background: #dbeafe; color: #2563eb; }
.tag.yellow { background: #fef9c3; color: #ca8a04; }
.tag.orange { background: #ffedd5; color: #ea580c; }
.tag.red { background: #fee2e2; color: #dc2626; }

body.dark-mode .tag.green { background: #052e16; color: #4ade80; }
body.dark-mode .tag.blue { background: #172554; color: #60a5fa; }
body.dark-mode .tag.yellow { background: #422006; color: #facc15; }
body.dark-mode .tag.orange { background: #431407; color: #fb923c; }
body.dark-mode .tag.red { background: #450a0a; color: #f87171; }

/* ---- Result Details ---- */
.result-details {
    display: flex;
    flex-direction: column;
    gap: 6px;
    margin: 12px 0;
}

.detail-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 14px;
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.04);
}

.detail-row .label {
    font-size: 13px;
    color: #94a3b8;
    font-weight: 500;
}

.detail-row .value {
    font-size: 14px;
    font-weight: 600;
    color: #0a1628;
}

body.dark-mode .detail-row .value {
    color: #e8f0f8;
}

/* ---- Result Actions ---- */
.result-actions {
    display: flex;
    gap: 12px;
    margin-top: 18px;
}

.result-actions .cta-button {
    flex: 1;
    margin-top: 0;
}

.result-actions .btn-outline {
    flex: 1;
    padding: 14px;
    border: 2px solid #e2e8f0;
    border-radius: 14px;
    background: transparent;
    font-size: 15px;
    font-weight: 600;
    font-family: inherit;
    color: #64748b;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

body.dark-mode .btn-outline {
    border-color: #2a3450;
    color: #6a8aaa;
}

.btn-outline:hover {
    background: #eef2f7;
    border-color: #1a3a8a;
    color: #1a3a8a;
    transform: translateY(-2px);
}

body.dark-mode .btn-outline:hover {
    background: #1e273a;
    border-color: #4a8af4;
    color: #4a8af4;
}

/* ============================================================
   📱 FOOTER
   ============================================================ */
.card-footer {
    text-align: center;
    margin-top: 16px;
    padding-top: 14px;
    border-top: 1px solid rgba(0, 0, 0, 0.04);
}

.card-footer p {
    font-size: 10px;
    color: #94a3b8;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
}

.card-footer i {
    color: #1a3a8a;
    font-size: 12px;
}

body.dark-mode .card-footer {
    border-top-color: rgba(255, 255, 255, 0.04);
}
body.dark-mode .card-footer p {
    color: #6a8aaa;
}
body.dark-mode .card-footer i {
    color: #4a8af4;
}

/* ============================================================
   📱 RESPONSIVE
   ============================================================ */
@media (max-width: 480px) {
    .main-wrapper {
        max-width: 100%;
        padding: 0 4px;
    }

    .assessment-card {
        padding: 20px 16px 16px;
        border-radius: 22px;
    }

    .accent-bar {
        border-radius: 22px 22px 0 0;
    }

    .card-header h1 {
        font-size: 20px;
    }
    .card-header p {
        font-size: 12px;
        line-height: 1.4;
    }
    .brand-icon svg {
        width: 40px;
        height: 40px;
    }

    .form-grid {
        gap: 8px;
    }
    .input-container input,
    .input-container select {
        padding: 8px 10px;
        font-size: 13px;
        border-radius: 8px;
    }
    .input-container label {
        font-size: 11px;
    }

    .form-subtitle {
        font-size: 12px;
        line-height: 1.5;
        padding: 0 4px;
        margin-bottom: 14px;
    }

    .step {
        width: 24px;
        height: 24px;
        font-size: 10px;
    }
    .step-line {
        width: 16px;
    }
    .step-label {
        font-size: 8px;
    }

    .cta-button {
        padding: 12px;
        font-size: 14px;
        border-radius: 10px;
    }

    .top-bar {
        top: 10px;
        right: 10px;
        gap: 6px;
    }

    .top-btn {
        width: 34px;
        height: 34px;
        font-size: 14px;
    }

    .lang-btn {
        font-size: 11px;
        padding: 0 12px;
        height: 34px;
    }

    .lang-btn i {
        font-size: 13px;
    }

    .back-btn {
        top: 12px;
        left: 12px;
        width: 32px;
        height: 32px;
        font-size: 13px;
    }

    .result-circle {
        width: 120px;
        height: 120px;
    }
    .result-circle .value {
        font-size: 34px;
    }
    .result-circle .unit {
        font-size: 13px;
    }
    .result-circle .status-badge {
        font-size: 12px;
        padding: 4px 16px;
        bottom: -12px;
    }
    .result-stats {
        grid-template-columns: repeat(3, 1fr);
        gap: 6px;
    }
    .stat-card .value {
        font-size: 15px;
    }
    .stat-card .icon {
        font-size: 14px;
    }

    .range-bar {
        font-size: 11px;
        gap: 8px;
    }
    .range-bar .range-line {
        max-width: 100px;
    }

    .exp-card {
        padding: 14px;
    }
    .exp-card .title {
        font-size: 13px;
    }
    .exp-card .desc {
        font-size: 12px;
    }

    .result-actions {
        flex-direction: column;
    }

    .detail-row {
        padding: 8px 12px;
    }
    .detail-row .label {
        font-size: 12px;
    }
    .detail-row .value {
        font-size: 13px;
    }

    .scan-box {
        width: 42%;
        height: 42%;
    }
    .box-border {
        border-width: 1.5px;
        border-radius: 10px;
    }
    .box-corner {
        width: 12px;
        height: 12px;
    }
    .box-corner::before {
        width: 8px;
        height: 1.5px;
    }
    .box-corner::after {
        width: 1.5px;
        height: 8px;
    }

    .btn-ring {
        width: 58px;
        height: 58px;
    }
    .btn-inner {
        width: 44px;
        height: 44px;
        font-size: 19px;
    }
    .capture-label {
        font-size: 11px;
    }

    .color-detection-box {
        bottom: 12px;
        padding: 5px 10px 5px 6px;
        border-radius: 10px;
        gap: 8px;
        max-width: 92%;
    }
    .color-preview {
        width: 26px;
        height: 26px;
        border-radius: 6px;
    }
    .color-value {
        font-size: 12px;
    }
}

@media (max-width: 380px) {
    .assessment-card {
        padding: 16px 12px 14px;
        border-radius: 18px;
    }

    .accent-bar {
        border-radius: 18px 18px 0 0;
    }

    .card-header h1 {
        font-size: 18px;
    }
    .form-grid {
        gap: 6px;
    }
    .input-container input,
    .input-container select {
        padding: 7px 8px;
        font-size: 12px;
    }
    .input-container label {
        font-size: 10px;
    }

    .form-subtitle {
        font-size: 11px;
        line-height: 1.4;
        margin-bottom: 12px;
    }

    .cta-button {
        padding: 10px;
        font-size: 13px;
    }

    .top-bar {
        top: 8px;
        right: 8px;
        gap: 4px;
    }

    .top-btn {
        width: 30px;
        height: 30px;
        font-size: 12px;
    }

    .lang-btn {
        font-size: 10px;
        padding: 0 10px;
        height: 30px;
    }

    .lang-btn i {
        font-size: 11px;
    }

    .result-circle {
        width: 100px;
        height: 100px;
    }
    .result-circle .value {
        font-size: 28px;
    }
    .result-circle .unit {
        font-size: 11px;
    }
    .result-circle .status-badge {
        font-size: 10px;
        padding: 3px 12px;
        bottom: -10px;
    }
    .result-stats {
        grid-template-columns: 1fr 1fr 1fr;
        gap: 4px;
    }
    .stat-card {
        padding: 10px 6px;
    }
    .stat-card .value {
        font-size: 13px;
    }
    .range-bar .range-line {
        max-width: 70px;
    }

    .scan-box {
        width: 44%;
        height: 44%;
    }
    .box-border {
        border-width: 1px;
        border-radius: 8px;
    }
    .box-corner {
        width: 10px;
        height: 10px;
    }
    .box-corner::before {
        width: 6px;
        height: 1.5px;
    }
    .box-corner::after {
        width: 1.5px;
        height: 6px;
    }

    .btn-ring {
        width: 50px;
        height: 50px;
        border-width: 2px;
    }
    .btn-inner {
        width: 38px;
        height: 38px;
        font-size: 16px;
    }
    .capture-wrapper {
        margin: 8px 0 0;
    }

    .color-detection-box {
        bottom: 10px;
        padding: 4px 10px 4px 6px;
        gap: 6px;
        border-radius: 8px;
        max-width: 94%;
    }
    .color-preview {
        width: 24px;
        height: 24px;
        border-radius: 6px;
    }
    .color-value {
        font-size: 11px;
    }
}